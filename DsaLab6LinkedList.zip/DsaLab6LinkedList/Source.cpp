#include "Header.h";
int main()
{
	node* head = nullptr;
	head->insertAtEnd(head, 1);
	head->insertAtEnd(head, 2);
	head->insertAtEnd(head, 3);
	//head->next->next->next = head;
	/*head->insertAtHead(head, 4);
	head->insertAtAfter(10, 21, head);
    head->insertAtBefore(11, 10, head);
	head->insertAtMid(head, 9);
	int front = head->getFront(head);
	cout << front;
	int end = head->getTail(head);
	cout << end;
	head->popMiddle(head);
	bool ans = head->searchElement(head, 21);
	cout << ans << endl;
	head-> popAtBack(head);
	bool check = head->isEmpty(head);
	cout << check;
	head->popAtHead(head);
	head->reversingList(head);
	head->RecursionReservingList(head, nullptr, head, head->next);*/
	bool result = head->isCircular(head);
	cout << result << endl;
	//head->display(head);
	/*stack<int> s1;
	s1.push(1);
	s1.push(13);
	s1.push(16);
	s1.push(18);
	s1.pop();
	s1.display();
	queue<int> q1;
	q1.push(1);
	q1.push(13);
	q1.push(16);
	q1.push(18);
	q1.pop();
	q1.display();*/
}