#pragma once
#include <iostream>
using namespace std;
class node
{
public :
	int data;
	node* next;
	node(int value)
	{
		data = value;
		next = nullptr;
	}
	//question1
	//1
	bool isEmpty(node*& head)
	{
		if (head == nullptr)
		{
			return true;
		}
		return false;
	}
	//2
	void insertAtHead(node*& head, int val)
	{
		node* n = new node(val);
		n->next = head;
		head = n;
	}
	//3
	void insertAtEnd(node* &head,int val)
	{
		node* n = new node(val);
		
		if (head== nullptr)
		{
			head = n;
			return;
		}
		node* temp = head;
		while (temp->next != nullptr)
		{
			temp = temp->next;
		}
		n->next = nullptr;
		temp->next = n;
	}
	//4
	void insertAtMid(node*& head, int val)
	{
		node* n = new node(val);
		node* slow = head;
		node* fast = head->next;
		while (fast!=nullptr&&fast->next != nullptr)
		{
			slow = slow->next;
			fast = fast->next->next;
		}
		n->next = slow->next;
		slow->next=n;
	}
	//5
	//a
	void insertAtAfter(int val,int whereToInsert, node*& head)
	{
		if (head==nullptr)
		{
			return;
		}
		node* n = new node(val);
		node* temp = head;
		while (temp != nullptr&&temp->data != whereToInsert )
		{
			temp = temp->next;
		}
		if (temp == nullptr)
		{
			delete n;
			return;
		}
		n->next = temp->next;
		temp->next = n;
	}
	//b
	void insertAtBefore(int val, int whereToInsert, node*& head)
	{
		if (head == nullptr) 
		{
			return;
		}
		node* n = new node(val);
		node* temp = head;
		while (temp != nullptr && temp->next->data != whereToInsert)
		{
			temp = temp->next;
		}
		if (temp == nullptr)
		{
			delete n;
			return;
		}
		n->next = temp->next;
		temp->next = n;
	}
	//6
	int getFront(node*& head)
	{
		if (isEmpty(head))
		{
			return -1;
		}
		return head->data;
	}
	//7
	int getTail(node*& head)
	{
		if (isEmpty(head))
		{
			return -1;
		}
		node* temp = head;
		while (temp->next != nullptr)
		{
			temp = temp->next; 
		}
		return temp->data;
	}
	//8
	bool searchElement(node*& head, int val)
	{
		node* temp = head;
		while (temp != nullptr)
		{
			if (temp->data == val)
			{
				return true;
			}
			temp = temp->next;
		}
		return false;
	}
	//9
	void popAtHead(node* &head)
	{
		if (head == nullptr)
		{
			return;
		}
		if (head->next == nullptr)
		{
			delete head;
			head = nullptr;
			return;
		}
	    node* temp = head;
		head = head->next;
		delete temp;
	}
	//a
	void popAtBack(node* &head)
	{
		if (head == nullptr)
		{
			return;
		}
		if (head->next == nullptr)
		{
			delete head;
			head = nullptr;
			return;
		}
		node* temp = head;
		while (temp->next->next!=nullptr)
		{
			temp = temp->next;
		}
		temp->next = nullptr;
	}
	//b
	void popMiddle(node*& head)
	{
		if (head==nullptr || head->next == nullptr)
		{
			return;
		}
		node* pre = nullptr;
		node* slow = head;
		node* fast = head->next;
		while (fast != nullptr && fast->next != nullptr)
		{
			pre = slow;
			slow = slow->next;
			fast = fast->next->next;
		}
		if (pre != nullptr)
		{
			pre->next = slow->next;
		}
		else
		{
			head = head->next;
			delete slow;
		}

	}
	//question 3
	//1a
	void display(node* &head)
	{
		if ( head == nullptr)
		{
			return;
		}
		node* temp = head;
		while (temp != nullptr)
		{
			cout << temp->data << "------";
			temp = temp->next;
		}
	}
	//1b
	 void reversingList(node*& head)
	{
		node* pre = nullptr;
		node* current = head;
		node* next = head->next;
		while (current != nullptr)
		{
			next = current->next;
			current->next = pre;
			pre = current;
			current = next;
		}
		head = pre;
	}
	 //3
	 bool isCircular(node*& head)
	 {
		 if (head == nullptr)
		 {
			 return true;
		 }
		 node* temp = head;
		 while (temp->next != nullptr&&temp->next !=head)
		 {
			 temp = temp->next;
		 }
		 if (temp->next == head)
			 return true;
		 return false;
	 }
	//4
	node* RecursionReservingList(node*& head, node* pre, node* current, node* next)
	{
		if (current==nullptr)
		{
			head = pre;
			return head;
		}
		next =  current->next;
		current->next = pre;
		RecursionReservingList(head, current, next, next);
	}
};
//question 2
//a
template <typename T>
class stack
{
private:
	class node
	{
	public:
		T data;
		node* next;
		node(T value)
		{
			data = value;
			next = nullptr;
		}
	};
	node* head;
public:
	stack()
	{
		head = nullptr;
	}
	void display()
	{
		if (head == nullptr)
		{
			return;
		}
		node* temp = head;
		while (temp != nullptr)
		{
			cout << temp->data << "------";
			temp = temp->next;
		}
	}
	void push(T val)
	{
		node* n = new node(val);

		if (head == nullptr)
		{
			head = n;
			return;
		}
		node* temp = head;
		while (temp->next != nullptr)
		{
			temp = temp->next;
		}
		n->next = nullptr;
		temp->next = n;
	}
	 void pop()
	{
		if (head == nullptr)
		{
			return;
		}
		if (head->next == nullptr)
		{
			delete head;
			head = nullptr;
			return;
		}
		node* temp = head;
		while (temp->next->next != nullptr)
		{
			temp = temp->next;
		}
		temp->next = nullptr;
	}
	 bool isEmpty()
	 {
		 if (head == nullptr)
		 {
			 return true;
		 }
		 return false;
	 }
};
//question 2
//b
template <typename T>
class queue
{
private:
	class node
	{
	public:
		T data;
		node* next;
		node(T value)
		{
			data = value;
			next = nullptr;
		}
	};
	node* head;
public:
	queue()
	{
		head = nullptr;
	}
	void display()
	{
		if (head == nullptr)
		{
			return;
		}
		node* temp = head;
		while (temp != nullptr)
		{
			cout << temp->data << "------";
			temp = temp->next;
		}
	}
	void push(T val)
	{
		node* n = new node(val);

		if (head == nullptr)
		{
			head = n;
			return;
		}
		node* temp = head;
		while (temp->next != nullptr)
		{
			temp = temp->next;
		}
		n->next = nullptr;
		temp->next = n;
	}
	void pop()
	{
		if (head == nullptr)
		{
			return;
		}
		if (head->next == nullptr)
		{
			delete head;
			head = nullptr;
			return;
		}
		node* temp = head;
		head = head->next;
		delete temp;
	}
	bool isEmpty()
	{
		if (head == nullptr)
		{
			return true;
		}
		return false;
	}
};
